% Input the parameters for the task 2
prompt={'Enter the video directory',...
    'Enter the query video name',...
    'Enter the frame range to be searched [a,b]',...
    'Enter the value for k most similar frames',...
    'Enter the method to be applied: 1 to 8',...
    'Enter the dimension its reduced'
    };
dlg_title='Input for Task 4';
num_lines=1;
default={'D:\ASU\MWDB\Project-2\videos\','6x_SQ_BL_TM_BR_Noise.mp4','[10,15]','2','1','6'};
input=inputdlg(prompt,dlg_title,num_lines,default);

dirPath=strcat(input{1},'\');
queryVideoName=input{2};
[seqStart,seqEnd] = (strread(input{3}, '[%d,%d]'));
kSimilar=str2num(input{4});
methodType=str2num(input{5});
redDim=str2num(input{6});
%VIDEO NUMBER TO SEARCH IN DB
video_no=0;
fprintf('%s \n %s \n %d-%d \n %d \n %d \n %d',...
dirPath,queryVideoName,seqStart,seqEnd,methodType,kSimilar,redDim);

%to get the video number from the video name
dirFiles=strcat(dirPath,'\*.mp4');
listOfVideoFiles=dir(dirFiles);
for i = 1 : length(listOfVideoFiles)
    videoFileName=listOfVideoFiles(i).name;
    if( strcmp(videoFileName,queryVideoName))
        video_no=i;
        break;
    end;
    disp(videoFileName);
end;

% Call function for histogram if methodType is 1 or 2
if( methodType == 1 || methodType == 2 )
    % Call Hist function
    message=Task_4_CHIST(dirPath,video_no,seqStart,seqEnd,methodType,kSimilar,redDim);
% Call function for SIFT if methodType is 3 or 4
elseif( methodType == 3 || methodType == 4 )
    % Call SIFT function
    type = floor(methodType/2); 
    message=Task_4_SIFT(dirPath,video_no,seqStart,seqEnd,type,kSimilar,redDim);
    fprintf('%s',message);
% Call function for motion vector if methodType is 5 or 6
elseif( methodType == 5 || methodType == 6 )
    % Call Motion Vector
    type = floor(methodType/3);
    message=MV_Sub_Seq_Red_Dim(dirPath,video_no,seqStart,seqEnd,type,kSimilar,redDim);
elseif ( methodType == 7 || methodType == 8)
    %Call overall
    
else
    fprintf('Not a valid method');
end;
% Call function for overall similarity if methodType is 7 or 8

