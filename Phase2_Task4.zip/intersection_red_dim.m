% Calculates the pearson coefficient similarity of two matrices using
% columns as vectors.

function intersection_percent = intersection_red_dim(frame_data_v1, ...
    frame_data_v2, cell_count)
    cells_sum = 0;

    for cell_index = 1:cell_count
        % Using intersection similarity on the reduced dimension
        cells_sum = cells_sum + intersection_similarity( ...
            frame_data_v1(cell_index), frame_data_v2(cell_index));
    end

    if (cells_sum == 0)
        intersection_percent = 0;
    else
        intersection_percent = cells_sum / cell_count;
    end
end


