function C = EuclideanDistance( A,B )
%Eucledian Distance of Matrix
% Given matrices A and B , Calculates the euclidean distance
[ Arows,Acolumns ] = size(A);
[ Brows,Bcolumns ] = size(B);
C = zeros(Arows,Brows);
for i = 1 : Arows
    for m = 1 : Brows
        %C(i,m) = 0;
        for k = 1 : Bcolumns
            C(i,m)= C(i,m) + (A(i,k) - B(m,k))^2;
        end;
        C(i,m)=sqrt(C(i,m));
    end;
end;
end

