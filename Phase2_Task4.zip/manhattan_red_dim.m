% Calculates the manhattan distance similarity of two matrices using 
% columns as vectors.

function avg_manhattan = manhattan_red_dim(frame_data_v1, ...
    frame_data_v2, cell_count)
    cells_sum = 0;

    for cell_index = 1:cell_count
        % Using manhattan distance on the reduced dimension
        diff_res = abs(frame_data_v1(cell_index) - ...
            frame_data_v2(cell_index));
        cells_sum = cells_sum + diff_res;
    end

    avg_manhattan = (cells_sum / cell_count);
end


