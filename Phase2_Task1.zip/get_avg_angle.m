function avg_angle = get_avg_angle(mv_v)
    angle_sum = 0;
    mv_count = 0;
    [nr nc] = size(mv_v);
    for mv_index = 1:nr
        angle_sum = angle_sum + atan2(mv_v(mv_index, 2), mv_v(mv_index, 1));
        mv_count  = mv_count + 1;
    end
    if (mv_count <= 0)
        avg_angle = 0;
    else
        % To represent the angle in between 2 Pi and 4 Pi. Otherwise using
        % the range 0 to 2 Pi could lead to ambiguity if there is no motion
        % vector present, resulting in zero same as if there is no
        % difference in the motion vectors between 2 frames of different 
        % videos.
        avg_angle = (angle_sum / mv_count) + 6.28;
    end
end