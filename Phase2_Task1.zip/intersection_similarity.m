function int_val = intersection_similarity(feature_1, feature_2)
    if ((feature_1 == 0) && (feature_2 == 0))    
        int_val = 1;
    elseif ((feature_1 == 0) || (feature_2 == 0))
        int_val = 0;
    elseif (feature_1 >= feature_2)
        int_val = (feature_2 / feature_1);
    else
        int_val = (feature_1 / feature_2);
    end
end