function [ message ] = Task_1_CHIST( videonumber1 , videonumber2 , imput)

clc;
%reading the file
fileID=fopen('C:\Users\sdeep\Downloads\Project2\Task1\out_file.chst');
cellFromFile = textscan(fileID,['<%f;%f;%f;',repmat('%f',1,10),' >'], 'delimiter',' ');
cellsFromFile = cell2mat(cellFromFile);
[m n]=size(cellsFromFile);
i=1;j=1;
    
 %getting data pertaining to each of the 2 videos for which similarity has
 %to be found
for(counter=1 :m)
    if(cellsFromFile(counter,1)==videonumber1)
        video1mat(i,:)=cellsFromFile(counter,1:end);
        i=i+1;
    end
     if(cellsFromFile(counter,1)==videonumber2)
        video2mat(j,:)=cellsFromFile(counter,1:end);
        j=j+1;
    end
end
if(videonumber1==videonumber2)
    video2mat=video1mat;
end
%calculating maximum number of frames in each video
maxFrameCountV1 = max(video1mat(:,1));
maxFrameCountV2 = max(video2mat(:,1));

frameCount=min([maxFrameCountV1,maxFrameCountV2]);
%computing similarity
switch imput
        case 1
            intersimi=IntersectionSimilarity(video1mat,video2mat);
            disp(intersimi*100);
            d=intersimi*100; 
        case 2
            tansimi=TanimotoSimilarity(video1mat,video2mat);
            tansimi=1-tansimi;
            disp(tansimi*100);
            d=tansimi*100;
    end

