% Input the parameters for the task 2
prompt={'Enter which of task-1 to be performed : a,b,c,d ',...
    'Enter the query video name 1',...
    'Enter the query video name 2',...
    'Enter the method to be applied: 1 or 2 of the task selected',...
    };
dlg_title='Input for Task 1';
num_lines=1;
default={'a','6x_SQ_BL_TM_BR_Check.mp4','6x_TR_BL_TR_Check.mp4','1'};
input=inputdlg(prompt,dlg_title,num_lines,default);

taskToBePerformed=input{1};
queryVideoName1=input{2};
queryVideoName2=input{3};
methodType=str2num(input{4});
%VIDEO NUMBERS TO COMPARE
video_1=0;
video_2=0;
fprintf('%s \n %s \n %s \n %d \n',taskToBePerformed,queryVideoName1,queryVideoName2,methodType);
dirPath='C:\Users\sdeep\Downloads\Task2Videos\';
%to get the video number from the video name
dirFiles=strcat(dirPath,'\*.mp4');
listOfVideoFiles=dir(dirFiles);
for i = 1 : length(listOfVideoFiles)
    videoFileName=listOfVideoFiles(i).name;
    if( strcmp(videoFileName,queryVideoName1))
        video_1=i;
    end;
    
    if( strcmp(videoFileName,queryVideoName2))
    video_2=i;
    end;
    %disp(videoFileName);
end;

% Call function for histogram if methodType is 1 or 2
if( strcmp(taskToBePerformed,'a') == 1 )
   histSimilarity=Task_1_CHIST(video_1,video_2,methodType); % Call Hist function
    
% Call function for SIFT if methodType is 3 or 4
elseif( strcmp(taskToBePerformed,'b') == 1 )
        siftSimilarity=SIFTSimilarity(video_1,video_2,methodType); % Call SIFT function

% Call function for motion vector if methodType is 5 or 6
elseif( strcmp(taskToBePerformed,'c') == 1 )
     motionSimilarity=MVSimilarity(video_1,video_2,methodType);    % Call Motion Vector
    
elseif ( strcmp(taskToBePerformed,'d') == 1 )
    %Call overall
    histSimilarity= Task_1_CHIST(video_1,video_2,methodType);
    siftSimilarity= SIFTSimilarity(video_1,video_2,methodType);
    motionSimilarity= MVSimilarity(video_1,video_2,methodType);
    
    if ( methodType == 1 )
    % using geometric mean to find overall similarity
    overallSimilarity= nthroot((histSimilarity * siftSimilarity * motionSimilarity ),3);
    fprintf('Overall Similarity : %f',overallSimilarity);
    else
    % max of the three
    similarityVector = [ histSimilarity,siftSimilarity,motionSimilarity];
    overallSimilarity = harmmean(similarityVector);
    end;
else
    fprintf('Not a valid method');
end;
% Call function for overall similarity if methodType is 7 or 8

