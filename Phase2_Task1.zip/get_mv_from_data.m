% Getting the distance covered along x,y axis for each frame of the 2 
% videos. Also removing rows containing all zeros in the matrix, as 
% these indicate no motion.

function [mv_v1, mv_v2] = get_mv_from_data(frame_data_v1, frame_data_v2)
    srcx_v1 = (frame_data_v1(:, 1));
    destx_v1 = (frame_data_v1(:, 3));
    srcy_v1 = (frame_data_v1(:, 2));
    desty_v1 = (frame_data_v1(:, 4));
	srcx_v2 = (frame_data_v2(:, 1));
    destx_v2 = (frame_data_v2(:, 3));
    srcy_v2 = (frame_data_v2(:, 2));
    desty_v2 = (frame_data_v2(:, 4));

    mv_v1 = [(srcx_v1 - destx_v1), (srcy_v1 - desty_v1)];
    mv_v1(all(mv_v1 == 0,2),:) = [];
    mv_v1 = mv_v1;
    mv_v2 = [(srcx_v2 - destx_v2), (srcy_v2 - desty_v2)];
    mv_v2(all(mv_v2 == 0,2),:) = [];
    mv_v2 = mv_v2;
end
