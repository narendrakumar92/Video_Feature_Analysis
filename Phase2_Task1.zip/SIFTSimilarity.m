function  percentage  = SIFTSimilarity(videoNumber1,videoNumber2,method)
%n = input('Please enter the operation to be performed: 1.Manhattan 2.Eucledian \n');
fileID=fopen('C:\Users\sdeep\Downloads\Project2\Task1\out_file.sift');
cellsFromFile = textscan(fileID,['<%f;%f;%f;[',repmat('%f',1,2),repmat('%f',1,130),']>'], 'delimiter',',');
matrixFromFile = cell2mat(cellsFromFile);
% get the matrices from the sift file
video1Mat = matrixFromFile(matrixFromFile(:,1) == videoNumber1, :);
video2Mat = matrixFromFile(matrixFromFile(:,1) == videoNumber2, :);

% to compare frame wise
maxFrameCountV1 = max(video1Mat(:,2));
maxFrameCountV2 = max(video2Mat(:,2));

% find min framecount to compare
frameCount=min([maxFrameCountV1,maxFrameCountV2]);

totalSimilarityCount=0;
totalSimilarityScore=0;
ssf=ones(1,frameCount);
scf=ones(1,frameCount);

for frame = 1 : frameCount
    frameV1Mat=video1Mat(video1Mat(:,2) == frame, :);
    frameV2Mat=video2Mat(video2Mat(:,2) == frame, :);
    %delete the first 7 column since we are comparing the sift descriptors
    %suggested by Lowe to find the similarity
    frameV1Mat(:,1:7)=[];
    frameV2Mat(:,1:7)=[];
    switch method
        
        case 1
            %disp('Calculating Manhattan Distance');
            ManDistPerFrame=ManhattanDistance(frameV1Mat,frameV2Mat);
            % sort the matrix to get the first and second minimum
            SortedManDistPerFrame=sort(ManDistPerFrame,2);
            [ smdr , smwc ] = size(SortedManDistPerFrame);
            %find secondMin/firstMin >= 1.5 , threshold used by Lowe's paper to
            %identify the potential match
            similarityCountperFrame=0;
            similarityScoreperFrame=0;
            for x = 1 : smdr
                if ( (SortedManDistPerFrame(x,2)/SortedManDistPerFrame(x,1)) >= 1.5 )
                    similarityScoreperFrame = similarityScoreperFrame + SortedManDistPerFrame(x,1);
                    similarityCountperFrame = similarityCountperFrame + 1;
                end;
            end;
            scf(frame)=similarityCountperFrame;
            ssf(frame)=similarityScoreperFrame;
            totalSimilarityCount=totalSimilarityCount+similarityCountperFrame;
            totalSimilarityScore=totalSimilarityScore+similarityScoreperFrame;
        case 2
            %disp('Calculating Mahanalobis Distance');
            % sort the matrix to get the first and second minimum
            EucDistPerFrame=EuclideanDistance(frameV1Mat,frameV2Mat);
            SortedEucDistPerFrame=sort(EucDistPerFrame,2);
            [ smdr , smwc ] = size(SortedEucDistPerFrame);
            %find secondMin/firstMin >= 1.5 , threshold used by Lowe's paper to
            %identify the potential match
            similarityCountperFrame=0;
            similarityScoreperFrame=0;
            for x = 1 : smdr
                if ( (SortedEucDistPerFrame(x,2)/SortedEucDistPerFrame(x,1)) >= 1.5 )
                    similarityScoreperFrame = similarityScoreperFrame + SortedEucDistPerFrame(x,1);
                    similarityCountperFrame = similarityCountperFrame + 1;
                end;
            end;
            scf(frame)=similarityCountperFrame;
            ssf(frame)=similarityScoreperFrame;
            totalSimilarityCount=totalSimilarityCount+similarityCountperFrame;
            totalSimilarityScore=totalSimilarityScore+similarityScoreperFrame;
            case 3
            %disp('Calculating Mahanalobis Distance');
            % sort the matrix to get the first and second minimum
            MahaDistPerFrame=MahalanobisDistance(frameV1Mat,frameV2Mat);
            SortedMahaDistPerFrame=sort(MahaDistPerFrame,2);
            [ smdr , smwc ] = size(SortedMahaDistPerFrame);
            %find secondMin/firstMin >= 1.5 , threshold used by Lowe's paper to
            %identify the potential match
            similarityCountperFrame=0;
            similarityScoreperFrame=0;
            for x = 1 : smdr
                if ( (SortedMahaDistPerFrame(x,2)/SortedMahaDistPerFrame(x,1)) >= 1.5 )
                    similarityScoreperFrame = similarityScoreperFrame + SortedMahaDistPerFrame(x,1);
                    similarityCountperFrame = similarityCountperFrame + 1;
                end;
            end;
            scf(frame)=similarityCountperFrame;
            ssf(frame)=similarityScoreperFrame;
            totalSimilarityCount=totalSimilarityCount+similarityCountperFrame;
            totalSimilarityScore=totalSimilarityScore+similarityScoreperFrame;
        otherwise
            disp('other selection');
    end;
end;

[v1r,v1c] = size(video1Mat);
percentageSimilar=((totalSimilarityCount/v1r)*100);
percentage=percentageSimilar;
%disp(percentageSimilar);
fclose(fileID);
end