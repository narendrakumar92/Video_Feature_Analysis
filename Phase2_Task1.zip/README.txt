<-------------------------------------------------------README--------------------------------------------------------------------------------------------------->
	*All the videos that are being compared should be in the same directory.
	*The files in_file.mvect,out_file.chst,out_file.sift should be found in the directory where MATLAB code is found.
	*All the files found in this folder should be copied and found in the same folder as the Task_1_Main before computation because of interdependency between the files 		for computation
------------------------------------------------------------------------------------------------------------------------------------------------------------------
1.	Download the MATLAB software for your operating system.
2.	Install the MATLAB software with all functionalities.
3.	Open the MATLAB code file �Task_1_Main.m�.
4.	Compile the program and run the program.
5.	Input the task to be performed a for color histogram, b for sift similarity, c for motion vector similarity and d for overall similarity.
6.	Input the video name of the video file 1 and video name of video file 2 which are to be compared and click OK.
6.	The similarity for the 2 videos will be displayed on the command window.
