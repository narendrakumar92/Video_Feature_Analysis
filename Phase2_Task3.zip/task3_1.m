prompt={'Enter which of task-3 to be performed : 1. Histogram(10D) 2. SIFT(128D) 3. Motion(16D)',...
    'Enter the D (reduced dimension)',...
    'Enter the inputfile path',...
    'Enter the outputfile name (D dimensions of input vector space)',...
    'Enter the outputfile name (Scores)',...
    };
dlg_title='Input for Task 3';
num_lines=1;
default={'1','10','C:\Users\naren\Desktop\Phase2\FINAL\INPUT\in_file.chst','C:\Users\naren\Desktop\Phase2\FINAL\OUTPUT PCA\out_file_d.cpca','C:\Users\naren\Desktop\Phase2\FINAL\OUTPUT PCA\out_file_d_score.cpca'}; %need to change if someother laptpo
input=inputdlg(prompt,dlg_title,num_lines,default);

taskToBePerformed=input{1};
Dimension=str2num(input{2});
inputfile=input{3};
outputfile=input{4};
outputfilescore=input{5};


%SIFT and histogram did for all videos, motion also for all video



switch taskToBePerformed
    case '1'
        
            %HIST ENTIRE STARTS
            fileID=fopen(inputfile);
            cellsFromFile = textscan(fileID,['<%f;%f;%f;',repmat('%f',1,10),'>'], 'delimiter',',');
            cellsFromFileRaw = cellsFromFile;
            Nval =10;
            C = [1 2 3]
            cellsFromFile(:,C) = []
            Rawdata = cell2mat(cellsFromFileRaw); 
            Predata = Rawdata(:,[1:3]);
            X = cell2mat(cellsFromFile);
            ODimension = [1:10];
            ODimension = transpose(ODimension);

            [coeff,score,latent,tsquared,explained,mu] = pca(X);
            no_dims = Dimension;
            M = coeff(:,[1:no_dims]); %Score as per project
            projection = score(:,[1:no_dims]); %k dimensional feature vector
            Postdata = [Predata,projection];
            [rowPostdata, colPostdata] = size(Postdata);

             fid=fopen(outputfile,'a');
            fidbshist=fopen(outputfilescore,'a');

             %histogram output
             for i = 1:rowPostdata
               tempmat1 = Postdata(i,[1:3]);
               tempmat2 = Postdata(i,[4:(no_dims+3)]);
               fprintf(fid,'<');

               fprintf(fid,[repmat('%d;', 1, size(tempmat1, 2)) ], tempmat1');

               fprintf(fid,[repmat('%f,', 1, size(tempmat2, 2)) ], tempmat2');

               fprintf(fid,'>\n');

            end 

            %printing the base index and score

            [rows, columns] = size(M);
            FINALVAL =  abs(M); %from stack overflow, the coeff should be in positive, so abs is used
            for xnewdim = 1:columns


                b = FINALVAL(:,xnewdim);
                c= [ODimension, b];

              val.OLD = ODimension;
              val.SCORE = b;


              [tmp ind]=sort(val.SCORE,'descend'); %tmp and ind has proper values

              [rowindexcount, colindexcount] = size(tmp);
              for rindex = 1:rowindexcount

                fprintf(fidbshist,'<%d;%d;%d>\n',xnewdim,ind(rindex,1),tmp(rindex,1));

              end
              ans = [ind,tmp]; %This has floats

            end

            fclose(fid);
            fclose(fidbshist);
            %HIST ENDS
    
    
    case '2'
    
        
        %SIFT ENTIRE starts
        fileID=fopen(inputfile);
        cellsFromFile = textscan(fileID,['<%f;%f;%f;[',repmat('%f',1,2),repmat('%f',1,130),']>'], 'delimiter',',');
        cellsFromFileRaw = cellsFromFile;
        Rawdata = cell2mat(cellsFromFileRaw); 
        Predata = Rawdata(:,[1:7]);
        COL = [1 2 3 4 5 6 7];
        cellsFromFile(:,COL) = [];
        X = cell2mat(cellsFromFile);
        ODimension = [1:128];
        ODimension = transpose(ODimension);

        [coeff,score,latent,tsquared,explained,mu] = pca(X);
        no_dims = Dimension;
        M = coeff(:,[1:no_dims]) %Score as per project
        projection = score(:,[1:no_dims]); %k dimensional feature vector
        Postdata = [Predata,projection];
        [rowPostdata, colPostdata] = size(Postdata);

         fid=fopen(outputfile,'a');
         fidbssift=fopen(outputfilescore,'a');
         %sift output
        for i = 1:rowPostdata
           tempmat1 = Postdata(i,[1:7]);
           tempmat2 = Postdata(i,[8:(no_dims+7)]);
           fprintf(fid,'<');

           fprintf(fid,[repmat('%d;', 1, size(tempmat1, 2)) ], tempmat1');
           fprintf(fid,'[');
           fprintf(fid,[repmat('%f,', 1, size(tempmat2, 2)) ], tempmat2');
           fprintf(fid,']');
           fprintf(fid,'>\n');

        end 




        [rows, columns] = size(M);
        FINALVAL =  abs(M); %from stack overflow, the coeff should be in positive, so abs is used
        for xnewdimen = 1:columns


            b = FINALVAL(:,xnewdimen);
            c= [ODimension, b];

          val.OLD = ODimension;
          val.SCORE = b;

          [tmp ind]=sort(val.SCORE,'descend') %tmp and ind has proper values

          [rowindexcountsift, colindexcountsift] = size(tmp);
          for rindex = 1:rowindexcountsift

            fprintf(fidbssift,'<%d;%d;%d>\n',xnewdimen,ind(rindex,1),tmp(rindex,1));

          end

          ans = [ind,tmp] %This has floats

        end

        fclose(fidbssift); 
        fclose(fid);

        %Sift ends here
    


 
    case '3'
        
        %Motion starts here

        sumframe=0;
        fileID=fopen(inputfile);

        cellsFromFile = textscan(fileID,['<%f;%f;%f;[',repmat('%f',1,7),']>'], 'delimiter',',');
        cellsFromFileRaw = cellsFromFile;
        Rawdata = cell2mat(cellsFromFileRaw); 
        Predata = Rawdata(:,[1:6]);
        %C = [1 2 3 4 5 6]

        %cellsFromFile(:,C) = []

        X = cell2mat(cellsFromFile);

        %R value computation
        findR =  max(X(:,3));
        countdigit = numel(num2str(findR))
        R=mod(findR,power(10,countdigit/2));


        maxvideocount = max(X(:,1));

        fid=fopen(outputfile,'a');
        fidbs=fopen(outputfilescore,'a');
        for videoiter = 1:maxvideocount
        video_filtered = X(X(:, 1) == videoiter, :);  %Filtered for first video
        startframe = 2;

        MaxframeNo =  max(video_filtered(:,2)); %gives the max frame no

        sumframe = sumframe+  MaxframeNo;



        cell_direction = zeros(MaxframeNo,(R+1)*(R+1));
        cell_direction_iter=1;

        ODimension = [1:(R+1)*(R+1)];
        ODimension = transpose(ODimension);

         Max1 = max(video_filtered(:,9));
           Max2 = max(video_filtered(:,10));


        for frameno = startframe:MaxframeNo

            disp(frameno);
        Frame_filtered = video_filtered(video_filtered(:, 2) == frameno, :); %filtered for second frame
        cell_direction_iter=1;
        for icell=0:R
            for jcell=0:R

                cellnum = strcat(num2str(icell),num2str(jcell));
                cellnum = str2num(cellnum);
                cell_filtered = Frame_filtered(Frame_filtered(:, 3) == cellnum, :);
                [row_cell col_cell] = size(cell_filtered);
                for islope=1:row_cell
                    Yval = cell_filtered(islope,8)-cell_filtered(islope,10); %x1,y1 should be destx and desty; x2 y2 should be srcx and srx y
                    newmat(islope,1)=Yval;
                    Xval = cell_filtered(islope,7)-cell_filtered(islope,9);
                     newmat(islope,2)=Xval;


                       radianval =atan2(Yval,Xval);
                       newmat(islope,3)=radianval;


                end
                anglematrix = newmat(:, 3)

                anglematrixmean = mean(anglematrix(anglematrix~=0));
                anglematrixmean  = anglematrixmean+6.28; %adding 2*pi to transform to new space to avoid motion going left
                if(isnan( anglematrixmean))
                    anglematrixmean = 0;
                end


                cell_direction(frameno,cell_direction_iter) = anglematrixmean;
                cell_direction_iter = cell_direction_iter+1;



            end
        end
        end
        %motion alone
        %{ 
        % This is just to visually check the motion vectors 
        %guassian check
        v = VideoWriter('peaks.avi');
        open(v);
        Z = cell_direction;
        surf(Z); 
        axis tight manual 
        set(gca,'nextplot','replacechildren'); 
        for k = 1:20 
           surf(sin(2*pi*k/20)*Z,Z)
           frame = getframe;
           writeVideo(v,frame);
        end

        close(v);
        %}

        [coeff,score,latent,tsquared,explained,mu] = pca(cell_direction);
        no_dims = Dimension;
        M = coeff(:,[1:no_dims]) %Score as per project
        projection = score(:,[1:no_dims]); %k dimensional feature vector
        [rowPostdata, colPostdata] = size(projection);

        for i = 1:rowPostdata

           tempmat1 = projection(i,[1:no_dims]);
           fprintf(fid,'<%d;%d;',videoiter,i);
           fprintf(fid,[repmat('%d,', 1, size(tempmat1, 2)) ], tempmat1');
           fprintf(fid,'>\n');
        end


        %printing the base index and score

        [rows, columns] = size(M);
        FINALVAL =  abs(M); %from stack overflow, the coeff should be in positive, so abs is used
        for xnewdim = 1:columns


            b = FINALVAL(:,xnewdim);
            c= [ODimension, b];

          val.OLD = ODimension;
          val.SCORE = b;


          [tmp ind]=sort(val.SCORE,'descend'); %tmp and ind has proper values, printing this values

          [rowindexcount, colindexcount] = size(tmp);
          for rindex = 1:rowindexcount

            fprintf(fidbs,'<%d;%d;%d;%d>\n',videoiter,xnewdim,ind(rindex,1),tmp(rindex,1));

          end
              ans = [ind,tmp] %This has floats

            end
        end
        fclose(fidbs);
        fclose(fid);
        %motion alone ends
        %Motion ends here

end
 
 


 
    