function [ message ] = Task_2_CHIST(dirPath, queryVideoNumber , seqStart ,seqEnd , methodType ,kSimilar)
%clear window and workspace
clc; 
clear all;
%methodType=input('Please enter the operation to be performed: 1.Intersection Similarity 2.Tanimoto Similarity\n');;
%kSimilar=input('Enter the k for most similar values');
%reading file
fileID=fopen('C:\Users\sdeep\OneDrive\Documents\MATLAB\out_file.chst');
cellFromFile = textscan(fileID,['<%f;%f;%f;',repmat('%f',1,10),' >'], 'delimiter',' ');
cellsFromFile = cell2mat(cellFromFile);
%queryVideoNumber=input('Please Enter Video Number');
%seqStart=input('Please Enter sequence start value');
%seqEnd=input('Please Enter query sequencce end value');
[n m]=size(cellsFromFile);
querysize=seqEnd-seqStart+1;
bincount=m-3;
%getting query data
for querycopier=seqStart:seqEnd
    QueryVideoData=cellsFromFile(cellsFromFile(:,1)==queryVideoNumber,:);
    if(querycopier==seqStart)
        QueryVideoSearch=QueryVideoData(QueryVideoData(:,2)==querycopier,:);
    else
        QueryVideoSearch=[QueryVideoSearch;QueryVideoData(QueryVideoData(:,2)==querycopier,:)];
    end
end
videonumber=max(cellsFromFile(:,1));
counter=1;
%finding similarity of the video sequences and the query sequence
for i=1:videonumber
    %taking all the histogram data other than the query video
    if ( i ~= queryVideoNumber)
        MatrixVideoData=cellsFromFile(cellsFromFile(:,1)==i,:);
        maxFrames=max(MatrixVideoData(:,2));
        for numberc=1:maxFrames-querysize+1
            currentframenumber=numberc;
            currentfilenumber=i;
            for dbcopier=0:querysize-1 %copying n number of frames for comparison where n is the size of query sequence
                if(dbcopier==0)
                    matrixFromDB=MatrixVideoData(MatrixVideoData(:,2)==numberc+dbcopier,:);
                else
                    matrixFromDB=[matrixFromDB;MatrixVideoData(MatrixVideoData(:,2)==numberc+dbcopier,:)];
                end
            end
            %selecting the similarity measure
            switch methodType
                case 1
                    SimilarityPercentage(counter,1)=IntersectionSimilarity(matrixFromDB,QueryVideoSearch);
                case 2
                    SimilarityPercentage(counter,1)=TanimotoSimilarity(matrixFromDB,QueryVideoSearch);
            end
            SimilarityPercentage(counter,2)=currentfilenumber;
            SimilarityPercentage(counter,3)=currentframenumber;
            counter=counter+1;
        end
        
    else
        continue;
    end
end
if(methodType==1)
    sortedSimilarity=sortrows(SimilarityPercentage,-1); %sorting descending order since higher intersection similarity is more similar videos
elseif(methodType==2)
    sortedSimilarity=sortrows(SimilarityPercentage,1); %sorting in ascending order since lower the euclidean distance value higher the similarity between the videos
end

%directory where videos are found
dirPath = 'C:\Users\sdeep\Downloads\Task2Videos\';
dirFiles = strcat(dirPath,'\*.mp4');
listVideoFiles=dir(dirFiles);

%getting k most similar video sequences for the query sequence
for p = 1 : kSimilar
    for q = 1 : length(listVideoFiles) 
        if ( sortedSimilarity(p,2) == q ) 
            videoFileName=listVideoFiles(q).name;
            videoFrames= VideoReader(strcat(dirPath,videoFileName));
            similarFrameSeqStart = sortedSimilarity(p,3);
            similarFrameSeqEnd = similarFrameSeqStart+querysize-1;
            % to create a video sequence
            videoName = strcat(dirPath,'db_sequence_',num2str(p),'.avi');
            writerObj = VideoWriter(videoName);
            writerObj.FrameRate = 1;
            % set the seconds per image
            secsPerImage = [5 10 15];
            open(writerObj);
            for r = similarFrameSeqStart : similarFrameSeqEnd
                currentFrameGray=rgb2gray(read(videoFrames,r));
                writeVideo(writerObj, currentFrameGray);
            end;
            close(writerObj);
        end;
        
        % generating query frame sequence for verification
        if( queryVideoNumber == q )
            videoFileName=listVideoFiles(q).name;
            videoFrames= VideoReader(strcat(dirPath,videoFileName));
            % to create a video sequence
            videoName = strcat(dirPath,'query_sequence_',num2str(queryVideoNumber),'.avi');
            writerObj = VideoWriter(videoName);
            writerObj.FrameRate = 1;
            % set the seconds per image
            secsPerImage = [5 10 15];
            open(writerObj);
            for r = seqStart : seqEnd
                currentFrameGray=rgb2gray(read(videoFrames,r));
                writeVideo(writerObj, currentFrameGray);
            end;
            close(writerObj);    
        end;
    end;
end;
fclose(fileID);