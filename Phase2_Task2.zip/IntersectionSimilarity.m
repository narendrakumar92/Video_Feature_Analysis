function d = IntersectionSimilarity( video1mat , video2mat )
[n1, k1] = size(video1mat);
            [n2, k2] = size(video2mat);
            bincount1=k1-3;
            bincount2=k2-3;
            sum1=0;
            lower=min(n1,n2);
            if(bincount1==bincount2)
                for i=1:lower
                    max1=0;
                    min1=0;
                        for j=4:k1
                            max1=max1+max(video1mat(i,j),video2mat(i,j));
                            min1=min1+min(video1mat(i,j),video2mat(i,j));
                        end
                            checkpoint=max1+min1;
                        if(checkpoint==0)
                            sum1=sum1+1;
                        else
                           sum1=sum1+(min1./max1);
                        end
                end
            intersectionsim=(sum1/i);
            d=intersectionsim;
            end