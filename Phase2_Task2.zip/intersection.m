% Calculates the pearson coefficient similarity of two matrices using
% columns as vectors.

function intersection_percent = intersection(frame_data_v1, frame_data_v2)
    [mv_v1, mv_v2] = get_mv_from_data(frame_data_v1(:, 7:10), ...
        frame_data_v2(:, 7:10));
    cell_count = max(frame_data_v1(:, 3));
    cells_sum = 0;

    for cell_index = 1:cell_count
        cell_data_v1 = frame_data_v1(frame_data_v1(:, 3) == cell_index, :);
        cell_data_v2 = frame_data_v2(frame_data_v2(:, 3) == cell_index, :);
        [mv_v1, mv_v2] = get_mv_from_data(cell_data_v1(:, 7:10), ...
            cell_data_v2(:, 7:10));
        % Getting Euclidean distance
        avg_dist_v1 = get_euclid_dist(mv_v1);
        avg_dist_v2 = get_euclid_dist(mv_v2);
        % Getting the angle in radians per cell
        avg_angle_v1 = get_avg_angle(mv_v1);
        avg_angle_v2 = get_avg_angle(mv_v2);
        % Getting intersection ratio of features
        ratio_int_dist = intersection_similarity(avg_dist_v1, avg_dist_v2);
        ratio_int_angle = intersection_similarity(avg_angle_v1, avg_angle_v2);
        % Calculating the average intersection of two features
        avg_intersection = (ratio_int_dist + ratio_int_angle) / 2;
        cells_sum = cells_sum + avg_intersection;
    end

    if (cells_sum == 0)
        intersection_percent = 100;
    else
        intersection_percent = (cells_sum / cell_count) * 100;
    end
end

function avg_dist = get_euclid_dist(mv_v)
    dist_sum = 0;
    mv_count = 0;
    [nr nc] = size(mv_v);
    for mv_index = 1:nr
        dist_sum = sqrt((mv_v(mv_index, 2).^2) + (mv_v(mv_index, 1).^2));
        mv_count  = mv_count + 1;
    end
    if (mv_count <= 0)
        avg_dist = 0;
    else
        avg_dist = (dist_sum / mv_count);
    end
end

