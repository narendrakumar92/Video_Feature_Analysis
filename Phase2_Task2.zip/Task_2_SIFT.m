function [ message ] = Task_2_SIFT( p1 , p2, p3 , p4 , p5 , p6)
% file that contains the sift/hist/motion
fileID=fopen('C:\Users\sdeep\Downloads\Project2\Task2\out_file.sift');
cellsFromFile = textscan(fileID,['<%f;%f;%f;[',repmat('%f',1,2),repmat('%f',1,130),']>'], 'delimiter',',');
matrixFromFile = cell2mat(cellsFromFile);
% video file number to be taken as query
v_q = p2; % vi
% frame range to be compared from v_q (query video)
a = p3; %a
b = p4; %b
% frame length to be compared q-p+1
v_q_framerange = b - a + 1;
% k most similar frame sequence
k= p6;
% type of distance similarity to use
method= p5;
% get the matrix from the sift file for v_q
v_q_matrix = matrixFromFile(matrixFromFile(:,1) == v_q, :);

% get unique video files from the sift file
max_vid=unique( matrixFromFile(:,1) );
% get max count of videos
total_videos=max(matrixFromFile(:,1));
% get max count of frames
max_frames=max(matrixFromFile(:,2));
% max sequence match
MAX_MATCH=250;
% matrix to store the frame sequence and the similarity score
% for similar sequence of frames
% 250 -> assuming max 100 sequence match
% 2 + v_q_framerange -- > 2 is for video number and similarity percentage
% followed by frame sequence
k_most_similar_matrix=zeros(MAX_MATCH,2 + v_q_framerange);
% 2 -- > 1 st column as video #
% 2 nd column as similarity percentage #
% v_q_framerange -- > which frames matched in db videos
m = 1;
n = 1;
for v_db = 1 : size(max_vid)
    if ( v_db ~= v_q)
        fprintf('Video File %d \n',v_db);
        v_db_matrix = matrixFromFile(matrixFromFile(:,1) == v_db, :);
        %fc frame count
        v_db_fc = max(v_db_matrix(:,2));
    else
        continue;
    end;
    
    % simailarity matrix for a video - video comparison
    % eg : if video 1 , frame 1,2,3 matches video 2 , frame 4,5,6 it ll have
    % 1 as its column value in the corresponding columns
    % assuming for now max 100 frames per video
    similarity_matrix = zeros( v_db_fc + 10,max_frames + 10 );
    similarity_percentage_matrix=zeros( v_db_fc + 10,max_frames + 10 );
    for query_frame = a : b
        %fprintf('Query Frame %d \n',p);
        v_q_frameMatrix=v_q_matrix(v_q_matrix(:,2) == query_frame, :);
        %delete the first 7 column since we are comparing the sift descriptors
        %suggested by Lowe to find the similarity
        v_q_frameMatrix(:,1:7)=[];
        %fprintf('-------------\n');
        for db_frame = 1 : v_db_fc
            v_db_frameMatrix=v_db_matrix(v_db_matrix(:,2) == db_frame, :);
            v_db_frameMatrix(:,1:7)=[];
            switch method
                case 1
                    %disp('Calculating Manhattan Distance');
                    ManDistPerFrame=ManhattanDistance(v_q_frameMatrix,v_db_frameMatrix);
                    % sort the matrix to get the first and second minimum
                    SortedManDistPerFrame=sort(ManDistPerFrame,2);
                    [ smdr , smwc ] = size(SortedManDistPerFrame);
                    %find secondMin/firstMin >= 1.5 , threshold used by Lowe's paper to
                    %identify the potential match
                    similarityCountperFrame=0;
                    for x = 1 : smdr
                        distOffset = SortedManDistPerFrame(x,2) / SortedManDistPerFrame(x,1);
                        distOffset = floor(distOffset*100)/100;
                        % 1.06 giving better results
                        if ( distOffset >= 1.5 )
                            similarityCountperFrame = similarityCountperFrame + 1;
                        end;
                    end;
                    similarityPercentage = ( similarityCountperFrame / smdr ) * 100;
                    % 50 % giving better results
                    %if ( similarityPercentage >= 50 )
                        similarity_matrix(query_frame,db_frame) = 1;
                        similarity_percentage_matrix(query_frame,db_frame) = similarityPercentage;
                    %end;
                case 2
                    %disp('Calculating Mahanalobis Distance');
                    % sort the matrix to get the first and second minimum
                    EucDistPerFrame=EuclideanDistance(v_q_frameMatrix,v_db_frameMatrix);
                    SortedEucDistPerFrame=sort(EucDistPerFrame,2);
                    [ smdr , smwc ] = size(SortedEucDistPerFrame);
                    %find secondMin/firstMin >= 1.5 , threshold used by Lowe's paper to
                    %identify the potential match
                    similarityCountperFrame=0;
                    for x = 1 : smdr
                        distOffset = SortedEucDistPerFrame(x,2) / SortedEucDistPerFrame(x,1);
                        distOffset = floor(distOffset*100)/100;
                        if ( distOffset >= 1.5 )
                            similarityCountperFrame = similarityCountperFrame + 1;
                        end;
                    end;
                    similarityPercentage = ( similarityCountperFrame / smdr ) * 100;
                    %if ( similarityPercentage >= 50 )
                        similarity_matrix(query_frame,db_frame) = 1;
                        similarity_percentage_matrix(query_frame,db_frame) = similarityPercentage;
                    %end;
                otherwise
                    disp('other selection');
            end;
        end;
    end;
    % check if the query frame range matches any current video frame range
    
%         for dbf = 1 : v_db_fc - v_q_framerange
%             qf = a;
%             sequence_count=0;
%             frame_sequence= zeros(1,v_q_framerange);
%             i=1;
%             for seq = dbf : dbf + v_q_framerange
%                 if( similarity_matrix( qf , seq) == 1 )
%                     sequence_count = sequence_count + 1;
%                     qf = qf + 1 ;
%                     frame_sequence(i) = seq;
%                     i = i + 1;
%                 else
%                     break;
%                 end;
%             end;
%             if ( sequence_count == v_q_framerange )
%                 %fprintf('Sequence found:');
%                 k_most_similar_matrix( m, n )= v_db;
%                 n = n + 1;
%                 k_most_similar_matrix( m, n)= round(similarityPercentage);
%                 n = n + 1;
%                 for j = 1 : v_q_framerange
%                     k_most_similar_matrix( m,n)= frame_sequence(j);
%                     n = n + 1;
%                     fprintf('%d ',frame_sequence(j));
%                 end;
%                 fprintf('\n');
%                 m = m + 1;
%                 n = 1;
%             end;
%         end;
%     end;
    
    for dbf = 1 : v_db_fc - v_q_framerange
        qf=a;
        frame_sequence= zeros(1,v_q_framerange);
        averageSimilarity=0;
        xOffset=0;
        i=1;
        for seq = dbf : dbf + v_q_framerange
            %fprintf('Sequence found:');
            averageSimilarity= averageSimilarity + similarity_percentage_matrix( qf + xOffset, seq);
            %xOffset = xOffset + 1;
            xOffset = xOffset + 1;
            frame_sequence(i) = seq;
            i= i+ 1;
        end;
        
        averageSimilarity = averageSimilarity / v_q_framerange;
        k_most_similar_matrix( m, n )= v_db;
        n = n + 1;
        k_most_similar_matrix( m, n)= averageSimilarity;
        n = n + 1;
        for j = 1 : v_q_framerange
            k_most_similar_matrix( m,n)= frame_sequence(j);
            n = n + 1;
            %fprintf('%d ',frame_sequence(j));
        end;
        fprintf('\n');
        m = m + 1;
        n = 1;
    end;
end;

% sort the  similarity matrix , -2 sorts descendig column
sorted_k_most_similar_matrix = sortrows(k_most_similar_matrix,-2);
% read video files from the file
dirPath = p1;
dirFiles = strcat(dirPath,'\*.mp4');
listVideoFiles=dir(dirFiles);

for p = 1 : k
    for q = 1 : length(listVideoFiles)
        if ( sorted_k_most_similar_matrix(p,1) == q )
            videoFileName=listVideoFiles(q).name;
            fprintf('Video in which sequence matched: %s\n',videoFileName);
            videoFrames= VideoReader(strcat(dirPath,videoFileName));
            similarFrameSeqStart = sorted_k_most_similar_matrix(p,3);
            similarFrameSeqEnd = sorted_k_most_similar_matrix(p, 3 + v_q_framerange - 1 );
            % to create a video sequence
            videoName = strcat(dirPath,'task2_db_',num2str(q),'_',num2str(p),'.mp4');
            writerObj = VideoWriter(videoName);
            writerObj.FrameRate = 1;
            % set the seconds per image
            secsPerImage = [5 10 15];
            open(writerObj);
            for r = similarFrameSeqStart : similarFrameSeqEnd
                currentFrameGray=rgb2gray(read(videoFrames,r));
                writeVideo(writerObj, currentFrameGray);
            end;
            close(writerObj);
        end;
        
        % generating query frame sequence for verification
        if( v_q == q )
            videoFileName=listVideoFiles(q).name;
            videoFrames= VideoReader(strcat(dirPath,videoFileName));
            % to create a video sequence
            videoName = strcat(dirPath,'task2_query_',num2str(v_q),'.mp4');
            writerObj = VideoWriter(videoName);
            writerObj.FrameRate = 1;
            % set the seconds per image
            secsPerImage = [5 10 15];
            open(writerObj);
            for r = a : b
                currentFrameGray=rgb2gray(read(videoFrames,r));
                writeVideo(writerObj, currentFrameGray);
            end;
            close(writerObj);
        end;
    end;
end;
fclose(fileID);
message='success';
end