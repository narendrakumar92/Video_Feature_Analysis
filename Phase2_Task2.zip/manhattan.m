% Calculates the manhattan distance similarity of two matrices using 
% columns as vectors.

function manhattan_percent = manhattan(frame_data_v1, frame_data_v2)
    [mv_v1, mv_v2] = get_mv_from_data(frame_data_v1(:, 7:10), ...
        frame_data_v2(:, 7:10));
    cell_count = max(frame_data_v1(:, 3));
    cell_sums = 0;
    for cell_index = 1:cell_count
        cell_data_v1 = frame_data_v1(frame_data_v1(:, 3) == cell_index, :);
        cell_data_v2 = frame_data_v2(frame_data_v2(:, 3) == cell_index, :);
        [mv_v1, mv_v2] = get_mv_from_data(cell_data_v1(:, 7:10), ...
            cell_data_v2(:, 7:10));
        % Getting the angle in radians per cell
        avg_angle_v1 = get_avg_angle(mv_v1);
        avg_angle_v2 = get_avg_angle(mv_v2);
        % Using manhattan distance on one dimension
        angle_res = abs(avg_angle_v1 - avg_angle_v2);
        cell_sums = cell_sums + angle_res;
    end
    % Lesser the score the more similar the frames
    manhattan_percent = (cell_sums / cell_count);
    % To get percentage value
    manhattan_percent = 100 - ((manhattan_percent / 3.14) * 100);
end


