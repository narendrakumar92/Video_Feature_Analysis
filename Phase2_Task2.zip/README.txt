					CSE 515 Multimedia and Web Databases: Phase #2
					      Task 2: Video sub-sequence search

Assumptions: 
1. Given video files database in the form of histogram (.chst) file, SIFT (.sift) file and motion vector (.mvect) file.
2. User will input all 5 fields.
3. All videos being compared for sub-sequences should be in the same directory.
 

Inputs: 
i) Video filename - This refers to the absolute file path of the video file.
ii) a - A number to get the start frame.
iii) b - A number to get the end frame.
iv) k - A number to get the count of most similar sub-sequences.
v) n - A number which chooses the similarity function or method to be applied. Values can be 1 or 2.


Outputs:
Gets k sub-sequences videos in the video directory.

Steps:
i) Download the MATLAB software for your operating system.
ii) Install the MATLAB software with all functionalities.
iii) Open the MATLAB code file “Task_2_Main.m”.
iv) Compile the program and run the program.
v) Input the fields in the dialog prompt and click OK.