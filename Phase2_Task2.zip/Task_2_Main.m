% Input the parameters for the task 2
prompt={'Enter the video directory',...
    'Enter the query video name',...
    'Enter the frame range to be searched [a,b]',...
    'Enter the method to be applied: 1 to 8 from task 1',...
    'Enter the value for k most similar frames'
    };
dlg_title='Input for Task 2';
num_lines=1;
default={'C:\Users\sdeep\Downloads\Task2Videos\','6x_SQ_BL_TM_BR_Check.mp4','[3,4]','2','2'};
input=inputdlg(prompt,dlg_title,num_lines,default);

dirPath=strcat(input{1},'\');
queryVideoName=input{2};
[seqStart,seqEnd] = (strread(input{3}, '[%d,%d]'));
methodType=str2num(input{4});
kSimilar=str2num(input{5});
%VIDEO NUMBER TO SEARCH IN DB
video_no=0;
fprintf('%s \n %s \n %d-%d \n %d \n %d',dirPath,queryVideoName,seqStart,seqEnd,methodType,kSimilar);

%to get the video number from the video name
dirFiles=strcat(dirPath,'\*.mp4');
listOfVideoFiles=dir(dirFiles);
for i = 1 : length(listOfVideoFiles)
    videoFileName=listOfVideoFiles(i).name;
    if( strcmp(videoFileName,queryVideoName))
        video_no=i;
        break;
    end;
    disp(videoFileName);
end;

% Call function for histogram if methodType is 1 or 2
if( methodType == 1 || methodType == 2)
    message=Task_2_CHIST(dirPath,video_no,seqStart,seqEnd,methodType,kSimilar);
    fprintf('%s',message);
% Call function for SIFT if methodType is 3 or 4
elseif( methodType == 3 || methodType == 4 )
    % Call SIFT function
    type = floor(methodType/2); 
    message=Task_2_SIFT(dirPath,video_no,seqStart,seqEnd,type,kSimilar);
    fprintf('%s',message);
% Call function for motion vector if methodType is 5 or 6
elseif( methodType == 5 || methodType == 6)
    % Call Motion Vector
    type = floor(methodType/3);
    MV_Sub_Seq(dirPath,video_no,seqStart,seqEnd,type,kSimilar)
elseif ( methodType == 7 || methodType == 8)
    %Call overall
    
else
    fprintf('Not a valid method');
end;
% Call function for overall similarity if methodType is 7 or 8

