function [ C ] = ManhattanDistance( A,B )
%UNTITLED2 Manhattan distance
%   Calculates manhattan distance given two matrices
[ Arows,Acolumns ] = size(A);
[ Brows,Bcolumns ] = size(B);
C = zeros(Arows,Brows);
for i = 1 : Arows
    for m = 1 : Brows
        %C(i,m) = 0;
        for k = 1 : Bcolumns
            C(i,m)= C(i,m) + abs(A(i,k) - B(m,k));
        end;
    end;
end;

end

