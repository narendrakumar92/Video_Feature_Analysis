function [ percentage ] = MVSimilarity(i, j, n)
    dir = 'C:\Users\sdeep\Downloads\Project2\Task1\in_file.mvect';
    file_id = fopen(dir);        
    line_data = textscan(file_id, ['< %f%f%f [ ', repmat('%f', 1, ...
        7), ' ] >'], 'delimiter', ';');
    total_data = cell2mat(line_data);
    % Get data pertaining to each video by comparing all values of 1st
    % column (video file index) with i,j to get data of Vi and Vj
    % videos
    total_data_v1 = total_data(total_data(:, 1) == i, :);
    total_data_v2 = total_data(total_data(:, 1) == j, :);
    if (isempty(total_data_v1) || isempty(total_data_v2))
        uiwait(warndlg('No data found for given i or j'));
        return;
    end

    % Comparing frame wise and considering the minimum frame count
    max_frame_count_v1 = max(total_data_v1(:, 2));
    max_frame_count_v2 = max(total_data_v2(:, 2));
    frame_count = min([max_frame_count_v1, max_frame_count_v2]);
    avg_val = 0;
    % Skipping first frame which are absent for MV
    for frame_index = 2:frame_count
        frame_data_v1 = total_data_v1(total_data_v1(:, 2) == ...
            frame_index, :);
        frame_data_v2 = total_data_v2(total_data_v2(:, 2) == ...
            frame_index, :);
        % Calculating average Manhattan distance and Pearson 
        % coefficient similarity for motion vectors. Done by comparing
        % corresponding cells of same frames based on index from 2 
        % different videos. For Manhattan we get the slope angle of 
        % each motion vector as input and for Pearson we take a vector
        % as input consisting of 2 features; magnitude and slope angle.
        switch(n)
            case 1
            avg_val = avg_val + manhattan(frame_data_v1, ...
                frame_data_v2);
            case 2
            avg_val = avg_val + intersection( ...
                frame_data_v1, frame_data_v2);
        end
    end
    % Normalizing the values using the number of frames
    avg_val = avg_val / (frame_count - 1);

    if (n == 1)
        output_text = ['Motion similarity for videos %d and %d ' ... 
            'using Manhattan distance: %.4f'];
    else
        output_text = ['Motion similarity for videos %d and %d ' ...
         'using Intersection similarity: %.4f\n'];
    end
    output = sprintf(output_text, i, j, avg_val);
    disp(output);
    fclose(file_id);
    percentage = avg_val;
end

