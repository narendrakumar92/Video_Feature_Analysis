function [] = MV_Sub_Seq(vid_dir,i, a, b,n,k)
    output_file_path = 'sub_seq_video_path';
    %vid_dir = 'C:\Users\admin\Documents\Ravi\ASU\MWD-CSE 515\Project-Phase2\Inputs\Phase2_set\vid_dir\';
    file_id = fopen('C:\Users\sdeep\Downloads\Project2\Task2\in_file.mvect');
	line_data = textscan(file_id, ['< %f%f%f [ ', repmat('%f', 1, ...
            7), ' ] >'], 'delimiter', ';');
    query_frame_count = b - a + 1;
    total_data = cell2mat(line_data);
    query_video_data = total_data(total_data(:, 1) == i, :);
    video_count = size(unique(total_data(:, 1)));
    max_frame_count = max(total_data(:, 1));
    % Stores sub-sequences with each row having data for a video 
    % frame. Columns consist of video index, video frame index, 
    % average similarity percentages for consecutive frames.
    k_most_similar_matrix = zeros(k, 3);
    % Checking for all videos
    for video_index = 1:video_count
        % Skip query video
        if (video_index == i)
            continue;
        else
            % Comparing all values of 1st column (video file index) 
            % with video_index to get data of that video
            total_data_vi = total_data(total_data(:, 1) == ...
                video_index, :);
            if (isempty(total_data_vi))
                uiwait(warndlg('No data found!!'));
                return;
            end
        end
        total_vi_frame_count = max(total_data_vi(:, 2));
        % Checking for current video frames data
        % Also skipping first and last frames
        for video_frame_index = 1:(total_vi_frame_count - ...
                query_frame_count - 1)
            % Checking for query frames
            query_frame_percent_index = 1;
            frame_seq_sim_score = 0;
            sim_percent = 0;
            % Getting the similarity percentage
            for query_frame_index = a : b
                frame_data_v1 = query_video_data( ...
                    query_video_data(:, 2) == query_frame_index, :);
                frame_data_v2 = total_data_vi(total_data_vi(:, 2) ...
                    == (video_frame_index + ...
                    query_frame_percent_index), :);
                switch(n)
                    case 1
                    sim_percent = manhattan(frame_data_v1, ...
                        frame_data_v2);
                    case 2
                    sim_percent = intersection(frame_data_v1, ...
                        frame_data_v2);
                    otherwise
                    disp('\nInvalid similarity function option!!!\n');
                    return;
                end
                frame_seq_sim_score = frame_seq_sim_score + sim_percent;
                query_frame_percent_index = 1 + query_frame_percent_index;
            end
            trickle_down_flag = 0;
            curr_val = zeros(1, 3);
            prev_val = zeros(1, 3);
            curr_seq_avg_score = frame_seq_sim_score / query_frame_count;
            for k_index = 1:k
                if (trickle_down_flag == 0)
                    if (curr_seq_avg_score >= k_most_similar_matrix( ...
                            k_index, 3))
                        prev_val = k_most_similar_matrix(k_index, :);
                        k_most_similar_matrix(k_index, 1) = ...
                            video_index;
                        k_most_similar_matrix(k_index, 2) = ...
                            video_frame_index;
                        k_most_similar_matrix(k_index, 3) = ...
                            curr_seq_avg_score;
                        trickle_down_flag = 1;
                    end
                else
                    % Rebrand current row as previous row and store the
                    % row from previous iteration here.
                    curr_val = k_most_similar_matrix(k_index, :);
                    k_most_similar_matrix(k_index, :) = prev_val;
                    prev_val = curr_val;
                end
            end
        end
    end

    dir_files = strcat(vid_dir, '\*.mp4');
    video_files = dir(dir_files);

    % Visualizing of the sub-sequence videos
    for k_index = 1:k
        video_index = k_most_similar_matrix(k_index, 1);
        sub_seq_start = k_most_similar_matrix(k_index, 2);
        sub_seq_end = sub_seq_start + query_frame_count - 1;
        video_path = video_files(video_index).name;            
        video_reader = VideoReader(strcat(vid_dir, video_path));            
        video_name = strcat(vid_dir, 'subsequence_', ...
            num2str(k_index), '.avi');
        video_writer = VideoWriter(video_name);
        if (query_frame_count > 10)
            video_writer.FrameRate = video_reader.FrameRate;
        else
            video_writer.FrameRate = query_frame_count;
        end
        open(video_writer);
        for sub_seq_index = sub_seq_start:sub_seq_end
            frame_gray = rgb2gray(read(video_reader, sub_seq_index));
            writeVideo(video_writer, frame_gray);
        end
        close(video_writer);
    end

    % Visualizing the query
    video_path = video_files(i).name;
    video_reader = VideoReader(strcat(vid_dir, video_path));
    video_name = strcat(vid_dir, 'query', '.avi');
    video_writer = VideoWriter(video_name);
    if (query_frame_count > 10)
        video_writer.FrameRate = video_reader.FrameRate;
    else
        video_writer.FrameRate = query_frame_count;
    end
    open(video_writer);
    for query_index = a:b
        frame_gray = rgb2gray(read(video_reader, query_index));
        writeVideo(video_writer, frame_gray);
    end
    close(video_writer);
    message1='Success';
    fclose(file_id);
end
